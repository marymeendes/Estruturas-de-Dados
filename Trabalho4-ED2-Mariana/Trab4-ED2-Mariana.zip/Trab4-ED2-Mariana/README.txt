Neste zip se encontra o algoritmo da Tabela Hash
A função main deste programa utiliza as demais funções seguindo o exemplo dos slides de aula.

Programa feito por Mariana Mendes da Silva

Para executá-lo abra o terminal no diretório dos arquivos e digite:
gcc -o testeFinal cliente.c lista.c compartimento_hash.c main.c -Wall [ENTER]
./testeFinal [ENTER]

obs.: "testeFinal" pode ser substituído por outro nome de preferência

Após a execução do programa, caso queira visualizar o arquivo "clientes.dat",
basta digitar no terminal:
gcc -o t cliente.c lista.c testeLeRegistro.c -Wall [ENTER]
./t [ENTER]
clientes.dat [ENTER]

obs.2: "t" também pode ser substituído por outro nome de preferência

:D
