gcc -o teste listaV.c listaE.c kruskal.c main.c -Wall

*tem um warning, mas não é um problema

Exemplo:

Grafo de slide, numerar os vértices na ordem alfabética:
a = 0;
b = 1;
c = 2;
d = 3;
e = 4;

